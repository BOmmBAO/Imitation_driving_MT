from __future__ import division
from __future__ import print_function
from __future__ import absolute_import

import gym
from rl_algorithm.PETS_decision.dmbrl.env.carla import CarlaEnv
import math
import numpy as np
import tensorflow as tf
from utils.common import *
from dotmap import DotMap
import matplotlib.pyplot as plt

from rl_algorithm.PETS_decision.dmbrl.misc.DotmapUtils import get_required_argument
from rl_algorithm.PETS_decision.dmbrl.modeling.layers import FC


class CarlaConfigModule:
    ENV_NAME = "MBRL-Carla-v0"
    TASK_HORIZON = 200
    NTRAIN_ITERS = 200
    NROLLOUTS_PER_ITER = 1
    PLAN_HOR = 5
    MODEL_IN, MODEL_OUT = 135, 28
    GP_NINDUCING_POINTS = 50

    def __init__(self):
        self.ENV = gym.make(self.ENV_NAME)
        cfg = tf.ConfigProto()
        cfg.gpu_options.allow_growth = True
        self.SESS = tf.Session(config=cfg)
        self.NN_TRAIN_CFG = {"epochs": 5}
        self.OPT_CFG = {
            "Random": {
                "popsize": 100
            },
            "CEM": {
                "popsize": 30,
                "num_elites": 10,
                "max_iters": 5,
                "alpha": 0.1
            }
        }

    @staticmethod
    def obs_postproc(obs, pred):
        return tf.concat([pred[:, 0:28], obs[:, 28:]], axis=1)
        # return pred

    @staticmethod
    def targ_proc(obs, next_obs):
        return next_obs[:, 0:28]
        # return next_obs

    def nn_constructor(self, model_init_cfg):
        model = get_required_argument(model_init_cfg, "model_class", "Must provide model class")(DotMap(
            name="model", num_networks=get_required_argument(model_init_cfg, "num_nets", "Must provide ensemble size"),
            sess=self.SESS, load_model=model_init_cfg.get("load_model", False),
            model_dir=model_init_cfg.get("model_dir", None)
        ))
        if not model_init_cfg.get("load_model", False):
            model.add(FC(500, input_dim=self.MODEL_IN, activation='swish', weight_decay=0.0001))
            model.add(FC(500, activation='swish', weight_decay=0.00025))
            model.add(FC(500, activation='swish', weight_decay=0.00025))
            model.add(FC(500, activation='swish', weight_decay=0.00025))
            model.add(FC(200, activation='swish', weight_decay=0.00025))
            model.add(FC(self.MODEL_OUT, weight_decay=0.0005))
        model.finalize(tf.train.AdamOptimizer, {"learning_rate": 0.001})
        return model

    def gp_constructor(self, model_init_cfg):
        model = get_required_argument(model_init_cfg, "model_class", "Must provide model class")(DotMap(
            name="model",
            kernel_class=get_required_argument(model_init_cfg, "kernel_class", "Must provide kernel class"),
            kernel_args=model_init_cfg.get("kernel_args", {}),
            num_inducing_points=get_required_argument(
                model_init_cfg, "num_inducing_points", "Must provide number of inducing points."
            ),
            sess=self.SESS
        ))
        return model


    @staticmethod
    def obs_cost_fn(obs_traj, obs_index, sigmas):
        rewd_traj = 0
        for obs in obs_traj:
            # CarlaConfigModule._obs_display(obs, obs_index)
            car_v, lane_width, vel_des = CarlaConfigModule._get_vehicle_info(obs, obs_index)
            wp_x, wp_y, wp_yaw = CarlaConfigModule._get_waypoints(obs, obs_index)

            nearest_point, nearest_dist = None, 10
            for [x, y, yaw] in zip(wp_x, wp_y, wp_yaw):
                _dist = np.hypot(x, y)
                if _dist < nearest_dist:
                    nearest_point = [x, y, yaw]
                    nearest_dist = _dist

            if nearest_point == None:
                print("Error!")

            # sigma_pos = 0.3
            sigma_pos = sigmas["sigma_pos"]
            phi = math.atan2(nearest_point[1], nearest_point[0])
            delta = pi_2_pi(wp_yaw[0] - phi)
            ct_err = math.sin(delta) * nearest_dist  # Cross Track Error
            track_err = abs(ct_err) / lane_width
            track_rewd = np.exp(-track_err**2 / (2 * sigma_pos**2))

            sigma_vel_upper, sigma_vel_lower = sigmas["sigma_vel_upper"], sigmas["sigma_vel_lower"]
            sigma_vel = sigma_vel_upper if car_v <= vel_des else sigma_vel_lower
            v_err = car_v - vel_des
            v_rewd = np.exp(-v_err**2 / (2*sigma_vel**2))

            sigma_yaw = sigmas["sigma_yaw"]
            yaw_err = abs(pi_2_pi(nearest_point[2]))
            ang_rewd = np.exp(-yaw_err**2 / (2 * sigma_yaw **2))

            accident_cost = -10 if CarlaConfigModule._check_collision(obs, obs_index) or \
                                   CarlaConfigModule._check_laneinvasion(obs, obs_index) else 0

            rewd_traj += track_rewd * v_rewd * ang_rewd + accident_cost

        return rewd_traj

    @staticmethod
    def _obs_display(obs, obs_index):
        _index = obs_index['zombie_cars_pos']
        obs_zombie = obs[_index[0]: _index[1]]

        obs_lane = []
        lines = ['inner_line_right', 'inner_line_left', 'outer_line_right', 'outer_line_left']
        for line_name in lines:
            _index = obs_index[line_name]
            obs_lane.extend(obs[_index[0]: _index[1]])

        plt.clf()
        fig = plt.figure(1)
        ax2 = fig.gca()

        my_ticks = np.arange(-70, 75, 5)

        plt.xticks(my_ticks)
        plt.yticks(my_ticks)
        plt.xlim((-70, 75))
        plt.ylim((-70, 75))

        for p in range(int(len(obs_lane) / 2)):
            plt.plot(obs_lane[p * 2 + 1], obs_lane[p * 2], '.', color='red', label='lane')

        for q in range(int(len(obs_zombie) / 2)):
            plt.plot(obs_zombie[q * 2 + 1], obs_zombie[q * 2], '.', color='green', label='zombie_car')

        plt.draw()
        plt.pause(0.0001)  # pause for update


    @staticmethod
    def _get_vehicle_info(obs, obs_index):
        _index = obs_index['ego_car_vel']
        _v = obs[_index[0]:_index[1]]
        v = np.hypot(_v[0], _v[1])
        _index = obs_index['lane_width']
        lane_width = obs[_index[0]:_index[1]]
        _index = obs_index['ego_car_des_vel']
        vel_des = obs[_index[0]:_index[1]]
        return v, lane_width, vel_des

    @staticmethod
    def _get_waypoints(obs, obs_index):
        _index = obs_index['inner_line_right']
        inner_line_r = obs[_index[0]:_index[1]]
        _index = obs_index['inner_line_left']
        inner_line_l = obs[_index[0]:_index[1]]

        num = int(len(inner_line_l)/2)
        wp_x = [(inner_line_r[2*n]+inner_line_l[2*n])/2 for n in range(num)]
        wp_y = [(inner_line_r[2*n+1]+inner_line_l[2*n+1]) / 2 for n in range(num)]
        wp_yaw = [np.arctan2(wp_y[n+1]-wp_y[n], wp_x[n+1]-wp_x[n]) for n in range(num-1)]
        wp_yaw.append(wp_yaw[-1])
        return wp_x, wp_y, wp_yaw

    @staticmethod
    def _check_collision(obs, obs_index):
        _index = obs_index['zombie_cars_pos']
        zombie_cars = obs[_index[0]:_index[1]]
        num = int(len(zombie_cars) / 2)
        zcars_x = [zombie_cars[n] for n in range(num)]
        zcars_y = [zombie_cars[n+1] for n in range(num)]
        dist = []
        for n in range(num):
            if zcars_x != 0 and zcars_y != 0:
                dist.append(np.hypot(zcars_x[n], zcars_y[n]))
        return True if any(dist) < 3 else False

    @staticmethod
    def _check_laneinvasion(obs, obs_index):
        _index = obs_index['outer_line_right']
        outer_line_r = obs[_index[0]:_index[1]]
        _index = obs_index['outer_line_left']
        outer_line_l = obs[_index[0]:_index[1]]

        vec_1 = np.array([outer_line_r[0], outer_line_r[1]])
        vec_2 = np.array([outer_line_l[0], outer_line_l[1]])
        theta = cal_angle(vec_1, vec_2)

        if theta > math.pi/2:
            print('Vehicle is out of Lane!')
            return True
        else:
            return False

CONFIG_MODULE = CarlaConfigModule
