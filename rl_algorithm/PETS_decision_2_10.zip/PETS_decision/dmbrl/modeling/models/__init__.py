from .BNN import BNN
from .NN import NN
from .TFGP import TFGP
