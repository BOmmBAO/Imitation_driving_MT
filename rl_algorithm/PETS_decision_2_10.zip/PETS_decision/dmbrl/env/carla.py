import gym
from gym import spaces
import math
import carla
import argparse

try:
    import numpy as np
    import sys
    from os import path as osp
except ImportError:
    raise RuntimeError('import error!')
from carla_env.sim_carla import SimInit
from carla_env.sim_vehicle import VehicleInit
from utils.common import *
from carla_env.fplot import Plot_features


class CarlaEnv(gym.Env):

    def __init__(self):
        argparser = argparse.ArgumentParser(description='Carla ArgParser practice')
        argparser.add_argument('--host', metavar='H', default='127.0.0.1', help='IP of the host server')
        argparser.add_argument('-p', '--port', default=2000, type=int, help='TCP port to listen to')
        args = argparser.parse_args()

        self.sim = SimInit(args)
        self.car = VehicleInit(self.sim)
        self.sigma = {"sigma_pos": 0.3, "sigma_vel_upper": 0.6,
                       "sigma_vel_lower": 1.0, "sigma_yaw": 0.4}

        self.car_fea_ext = self.car.ego_car_config.fea_ext
        obs_shape = len(self.car_fea_ext.observation)
        obs_high = np.array([np.inf] * obs_shape)
        self.observation_space = spaces.Box(-obs_high, obs_high)
        self.obs_index = self.car_fea_ext.obs_index

        self.action_space = spaces.Discrete(5)  # discrete decision
        self.fea_plot = Plot_features(self.car_fea_ext)

    def step(self, decision):
        step_num = 5
        while step_num > 0:
            wrong_dec = self.car.step_decision(decision)
            self.car_fea_ext = self.car.ego_car_config.fea_ext
            self.sim.update()
            step_num -= 1
        ob = self._get_obs()
        if wrong_dec is True:
            reward = -10
            done = True
        else:
            done = True if self.sim.term_check() else False
            reward = self._get_reward(self.sigma)
        print("Decision:", decision)
        print("Reward:", reward)
        print("DONE?", done)
        return ob, reward, done, {}

    def reset(self):
        self.sim.reset()
        self.car.reset(self.sim)
        self.sim.update()
        ob = self._get_obs()
        return ob

    def test_step(self):
        self.sim.update()
        self.car.rule_based_step()
        ob = self._get_obs()
        reward = self._get_reward(self.sigma)
        done = False if self.sim.term_check() else True
        return ob, reward, done, {}

    def _get_obs(self):
        return self.car_fea_ext.observation

    def _plot_zombie_boxx(self, obs):
        self.fea_plot.plot_lane_andZombie_inEgoCar(obs)

    def _get_reward(self, sigmas):
        [rx, ry, ryaw, vel_des] = self.car.reference
        car_v = self.car_fea_ext.vehicle_info.v
        # velocity reward
        sigma_vel_upper, sigma_vel_lower = sigmas["sigma_vel_upper"], sigmas["sigma_vel_lower"]
        sigma_vel = sigma_vel_upper if car_v <= vel_des else sigma_vel_lower
        v_err = car_v - vel_des
        v_rewd = np.exp(-v_err**2 / (2*sigma_vel**2))
        accident_cost = -10 if self.sim.collision_event is True else 0
        reward = v_rewd + accident_cost

        # car_x, car_y, car_v, car_yaw = self.car_fea_ext.vehicle_info.x, self.car_fea_ext.vehicle_info.y, \
        #                         self.car_fea_ext.vehicle_info.v, self.car_fea_ext.vehicle_info.yaw
        # print("reward_info:", car_x, car_y, car_v, car_yaw)
        # if self.car.reference is None:
        #     return 0
        # [rx, ry, ryaw, vel_des] = self.car.reference
        # lane_width = self.car_fea_ext.cur_lane_width
        #
        # nearest_point, nearest_dist = None, 10
        # for [x, y, yaw] in zip(rx, ry, ryaw):
        #     _dist = np.hypot(car_x-x, car_y-y)
        #     if _dist < nearest_dist:
        #         nearest_point = [x, y, yaw]
        #         nearest_dist = _dist
        #
        # if nearest_point == None:
        #     print("Cannot find nearest point!")
        #
        # sigma_pos = 0.3
        # sigma_pos = sigmas["sigma_pos"]
        # phi = math.atan2(car_y - nearest_point[1], car_x - nearest_point[0])
        # delta = pi_2_pi(ryaw[0] - phi)
        # ct_err = math.sin(delta) * nearest_dist  # Cross Track Error
        # track_err = abs(ct_err) / lane_width
        # track_rewd = np.exp(-track_err**2 / (2 * sigma_pos**2))
        #
        # # velocity reward
        # sigma_vel_upper, sigma_vel_lower = sigmas["sigma_vel_upper"], sigmas["sigma_vel_lower"]
        # sigma_vel = sigma_vel_upper if car_v <= vel_des else sigma_vel_lower
        # v_err = car_v - vel_des
        # v_rewd = np.exp(-v_err**2 / (2*sigma_vel**2))
        #
        # # angle reward
        # sigma_yaw = sigmas["sigma_yaw"]
        # yaw_err = abs(pi_2_pi(nearest_point[2]-car_yaw))
        # ang_rewd = np.exp(-yaw_err**2 / (2 * sigma_yaw ** 2))
        #
        # accident_cost = -10 if self.sim.collision_event is True else 0
        # reward = track_rewd * v_rewd * ang_rewd + accident_cost

        return reward







